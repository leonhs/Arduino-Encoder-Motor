EncoderStepCounter library
==========================

A library which can be used th increment/decrement a counter based on rotary encoder movement.

It supports full-step and half-step encoders.

For more details on how to use this library, have a look at the examples.
